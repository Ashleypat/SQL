#Scipt Purpose: Create Tables that hold rows at highest risk of redundany

CREATE DATABASE v3;
use v3;
# TABLE 1: COUNTY FIPS AND COUNTY NAME
CREATE TABLE County_FIPS_Code(
	FIPS_Code int primary key,
    State_Code char(2),
    County_Name VARCHAR (50) #don't think >50 words required
    );

SET GLOBAL local_infile = true ;
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/DBM_Unemployment_csv.csv'
INTO TABLE County_FIPS_Code
FIELDS terminated BY ';;;'
LINES TERMINATED BY '\n'
IGNORE 0 LINES
(FIPS_Code, State_Code, County_Name, @dummy, @dummy, @dummy, @dummy);

UPDATE County_FIPS_Code #have to manually update  for some unexplained reason
SET FIPS_Code = 1000
WHERE FIPS_Code = 0;


# TABLE 2: STATE CODE AND STATE NAME

CREATE TABLE State_Code__State_Name AS
SELECT State_Code, County_Name
FROM County_FIPS_Code
WHERE FIPS_Code%1000 = 0;
ALTER TABLE State_Code__State_Name CHANGE County_Name State_Name varchar(50);


delete from County_FIPS_Code where FIPS_CODE % 1000 = 0; #removing non county areas in previous table



#TABLE 3 FIPS CODE - STATE CODE

CREATE TABLE FIPS_Code__State_Code AS
SELECT FIPS_Code, State_Code
FROM County_FIPS_Code;
Alter TABLE FIPS_CODE__State_Code
ADD PRIMARY KEY (FIPS_code);
select * from FIPS_Code__State_Code;

alter table County_FIPS_Code drop column State_Code;     # dropping now unnecessary column

#checking:
SELECT *  FROM County_FIPS_Code; #has county FIPS with County Name
SELECT *  FROM FIPS_Code__State_Code; #has county with state code
SELECT *  FROM State_Code__State_Name; # has state code with State name




