# Script for Loading the "Bulk" of the Data
# Note: Data paths likely have to be changed

USE V3;                    # calling database


##### CREATING TABLES #####

CREATE TABLE State_Freedom (          # creating table for Freedoms at the State Level
State varchar(255) PRIMARY KEY,
OverallRank INTEGER,
CorporateTaxRank INTEGER,
IndividualIncomeTaxRank INTEGER,
SalesTaxRank INTEGER,
UnemploymentInsuranceTaxRank INTEGER,
PropertyTaxRank INTEGER);

CREATE TABLE Counties(				   # creating table for UNEMPLOYMENT at the county level
FIPS_Code INTEGER PRIMARY KEY,
Unemployment_Rate_2021 float,            
Unemployment_Absolute_2021 INTEGER,
Median_HH_Income_2021 float ) ;          
 
CREATE TABLE cities (                  # Defining new table for CITIES
City varchar(255),
County_FIPS INT,
Population INT,
Density float,	
Military BOOLEAN,
Incorporated BOOLEAN,
Ranking INT,
PRIMARY KEY (City, County_FIPS)
);

##### LOADING DATA INTO TABLES ######

SET GLOBAL local_infile = true; # must be executed at the start of running each file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/DBM_Econ_Freedom_csv.csv'
INTO TABLE state_freedom
FIELDS terminated BY ',' ESCAPED BY '\t'
IGNORE 1 LINES;

SET GLOBAL local_infile = true; # must be executed at the start of running ecah file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/DBM_Unemployment_csv.csv'
INTO TABLE counties
FIELDS terminated BY ';;;' ESCAPED BY '\t'
IGNORE 0 LINES
(FIPS_Code, @dummy, @dummy, @Unemployment_Absolute_2021, @Unemployment_Rate_2021, @Median_HH_Income_2021)
SET 
	Unemployment_Absolute_2021 = NULLIF(@Unemployment_Absolute_2021, ""),
	Unemployment_Rate_2021 = NULLIF(@Unemployment_Rate_2021, ""),
    Median_HH_Income_2021 = NULLIF(@Median_HH_Income_2021, "");

# checking
select * from counties;
# for some reason I don't know, the first record isn't done properly. Since it's only
# one, let's do it manually - not ideal but gets the job done
UPDATE counties
SET FIPS_Code = 1000
WHERE FIPS_Code = 0;
select * from counties; # looks good


#Loading Cities:
SET GLOBAL local_infile = true; # must be executed at the start of running eah file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/cities_csv.csv'
INTO TABLE cities
FIELDS terminated BY ';;;' ESCAPED BY '\t'
IGNORE 0 LINES
(City, County_FIPS, @dummy, Population, Density, Military, Incorporated, Ranking);

#checking counties
select * from counties;
# this contains all the state level information (FIPS code multiple of 1000), this needs to be removed
delete from counties where FIPS_Code % 1000 = 0;
select * from counties; #looks good

# checking cities, looks good
select * from cities;

# checking state freedom, don't like that there is a state name instead of state code. Let's replace it
Create Table state_freedomB as
	select a.OverallRank,
	a.CorporateTaxRank,
	a.IndividualIncomeTaxRank,
	a.SalesTaxRank,
	a.UnemploymentInsuranceTaxRank,
	a.PropertyTaxRank,
    b.State_Code
	from state_freedom as a
	join state_code__state_name as b
	on a.State = b.State_Name;

drop table state_freedom; #delete old table with names as states 
alter table state_freedomB rename state_freedom; # now have new tables with codes as states
select * from state_freedom;

# still need to define a new primary key.
select * from counties;

