use v3;

# Aggregation, Group by, Filtering records, selection of attributes

#Business Question 1: Compare the effect of economic freedom on prosperity based on 
# county income bands (lower, median, upper)

#Step 1: Get a Table / Query for each county that outlines the  statistic for the relevant band. 
	#1.1 -> Determine what percentile each county is on income relative to the state
create temporary table one_one as
select c.FIPS_Code, Unemployment_Rate_2021, Unemployment_Absolute_2021, Median_HH_Income_2021, State_Code,
PERCENT_RANK() OVER (PARTITION BY fs.State_Code ORDER BY c.Median_HH_Income_2021 ASC) AS income_rank
from counties as c
join fips_code__state_code as fs 
on c.FIPS_Code = fs.FIPS_Code;

	
    #1.2 -> select just the lowest 10%, middle 50% or top 10% of state earners


create temporary table lowest_10 as
select State_Code,avg(Median_HH_Income_2021) as Lowest_10
from one_one
where income_rank <= 0.1
group by State_Code;



create temporary table middle_50 as
select State_Code, avg (Median_HH_Income_2021) as Median_50
from one_one 
where income_rank >= 0.25 and income_rank <= 0.75 
group by State_Code;


create temporary table top_10 as
select State_Code, avg (Median_HH_Income_2021) as Top_10
from one_one 
where income_rank >= 0.9
group by State_Code;





#1.3 Join Everything based on the Common state code, and also add economic freedom
create table freedom_distribution_income as
	select 
		a.*,
		b.Median_50,
		c.Top_10,
		d.CorporateTaxRank
	from 
		lowest_10 as a
	join 
		middle_50 as b on a.State_Code = b.State_Code
	join 
		Top_10 as c on a.State_Code = c.State_Code
	join state_freedom as d on a.State_Code = d.State_code;

select * from freedom_distribution_income; 

# Business Question 2: How is are county level inequalities effected by economic freedom (this time using overall rank)

# Below Groups together the counties data by state code and returns the differences between the highest and lowest income county.
create temporary table two_one as
	select b.state_code, max(Median_HH_Income_2021)- min(Median_HH_Income_2021) as Range_HH_Income
	from counties as a
	left join fips_code__state_code as b
	on a.FIPS_Code =b.FIPS_Code
	group by b.State_Code;

# 
create temporary table two_two as
	select a.*, b.OverallRank
    from two_one as a
    left join state_freedom as b
    on a.State_Code = b.State_code;

select * from two_two;

#idea: take top 5 of each and compare the means.













# Old Queries -- Not evaluated
#query to combine states with information on median household income
select counties.FIPS_Code, Median_HH_Income_2021, fips_code__state_code.State_Code
from counties, fips_code__state_code
where counties.FIPS_Code = fips_code__state_code.FIPS_Code;

# query, same as above, but save in new view "State_Avg_HH"
Create or replace view State_Avg_tbl as
select counties.FIPS_Code, Median_HH_Income_2021, fips_code__state_code.State_Code
from counties, fips_code__state_code
where counties.FIPS_Code = fips_code__state_code.FIPS_Code;

# median household income per state using view
create or replace view state_avg_HH as
select State_Code, avg(Median_HH_Income_2021) as avg_HH from State_Avg_tbl
group by State_Code;
select * from state_avg_HH;

select * from state_freedom;
select * from state_code__state_name;



#trying to add economic freedom indicator to previous table (ie make a simple correaltion setup)

# Business Question 1: Is there a correlation between Economic Success and State Freedom (multiple measures possible 
# for each variable (eg Taxation, Unemployment, Overall Rank)

select *#s.State_Code, s.avg_HH, f.OverallRank as FreedomOverallRank, c.State_Name # (uncomment and remove "*" to get clean view)
from state_avg_hh s																   # the full view makes the logic easier to
Join state_code__state_name c on s.State_Code = c.State_Code					   # understadn in my opinion
Join state_freedom f on c.State_Name = f.State;


# Busines Question 2:
# Does Business Freedom Play a Role in County level inequality of Economic Success?





# Step 1: Create a new view of county aggregates which has a measure of inequality


select State_Code,min(Median_HH_Income_2021), max(Median_HH_Income_2021), max(Median_HH_Income_2021)-min(Median_HH_Income_2021) as range_med_HH
from state_avg_tbl
group by State_Code;

# Step 2: Compare measure of inequality against measure of economic freedom?

# Optional: Integrate "cities" table to exlude conutiess with cities over population x and see if it makes a difference
# in the outcome.



