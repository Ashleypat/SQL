# Script for Creating Database, Creating Revant Tables and Loading Data
# Note: Data paths likely have to be changed

CREATE DATABASE SemProject_v2;        # creating the Database
USE SemProject_v2;                    # calling it


##### CREATING TABLES #####


CREATE TABLE State_Freedom (          # creating table for Freedoms at the State Level
State varchar(255) PRIMARY KEY,
OverallRank INTEGER,
CorporateTaxRank INTEGER,
IndividualIncomeTaxRank INTEGER,
SalesTaxRank INTEGER,
UnemploymentInsuranceTaxRank INTEGER,
PropertyTaxRank INTEGER);

CREATE TABLE Counties(				   # creating table for unemployment at the county level
FIPS_Code INTEGER PRIMARY KEY,
Area_Name TEXT,
State_Code varchar(2),
Unemployment_Rate_2021 INT,
Unemployment_Absolute_2021 INTEGER,
Median_HH_Income_2021 INT ) ;
 
CREATE TABLE cities (                  # Defining new table for cities
City varchar(255),
County_FIPS INT,
State_Code varchar(255),
Population INT,
Density float,	
Military BOOLEAN,
Incorporated BOOLEAN,
Ranking INT,
PRIMARY KEY (City, County_FIPS)
);

##### LOADING DATA INTO TABLES ######

TRUNCATE TABLE counties;                             
SET GLOBAL local_infile = true; # must be executed at the start of running eah file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/DBM_Econ_Freedom_csv.csv'
INTO TABLE state_freedom
FIELDS terminated BY ',' ESCAPED BY '\t'
IGNORE 1 LINES;

SET GLOBAL local_infile = true; # must be executed at the start of running eah file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/DBM_Unemployment_csv.csv'
INTO TABLE counties
FIELDS terminated BY ';;;' ESCAPED BY '\t'
IGNORE 0 LINES
(FIPS_Code, State_Code, Area_Name, @Unemployment_Absolute_2021, @Unemployment_Rate_2021, @Median_HH_Income_2021)
SET 
	Unemployment_Absolute_2021 = NULLIF(@Unemployment_Absolute_2021, ""),
	Unemployment_Rate_2021 = NULLIF(@Unemployment_Rate_2021, ""),
    Median_HH_Income_2021 = NULLIF(@Median_HH_Income_2021, "");

# checking
select * from counties;
# for some reason I don't know, the first record isn't done properly. Since it's only
# one, let's do it manually - I hate it as much as anyone else but I cannot seem to load
# it normally.
UPDATE counties
SET FIPS_Code = 1000
WHERE FIPS_Code = 0;
select * from counties; # looks good


#Loading Cities:
SET GLOBAL local_infile = true; # must be executed at the start of running eah file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/cities_csv.csv'
INTO TABLE cities
FIELDS terminated BY ';;;' ESCAPED BY '\t'
IGNORE 0 LINES;


drop database semproject_v2;