use semproject;

#Loading Economic Freedom Data
TRUNCATE TABLE counties;
SET GLOBAL local_infile = true; # must be executed at the start of running eah file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/DBM_Econ_Freedom_csv.csv'
INTO TABLE state_freedom
FIELDS terminated BY ',' ESCAPED BY '\t'
IGNORE 1 LINES;

#checking
select * from state_freedom;

#Loading Counties Data

SET GLOBAL local_infile = true; # must be executed at the start of running eah file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/DBM_Unemployment_csv.csv'
INTO TABLE counties
FIELDS terminated BY ';;;' ESCAPED BY '\t'
IGNORE 0 LINES
(FIPS_Code, State_Code, Area_Name, Unemployment_Absolute_2021, Unemployment_Rate_2021, Median_HH_Income_2021);

# checking
select * from counties;
# for some reason I don't know, the first record isn't done properly. Since it's only
# one, let's do it manually - I hate it as much as anyone else but I cannot seem to load
# it normally.
UPDATE counties
SET FIPS_Code = 1000
WHERE FIPS_Code = 0;

select * from counties; # looks good

truncate counties;

# Defining new table for cities
drop table cities;
CREATE TABLE cities (
City varchar(255),
County_FIPS INT,
State_Code varchar(255),
Population INT,
Density float,	
Military BOOLEAN,
Incorporated BOOLEAN,
Ranking INT,
PRIMARY KEY (City, County_FIPS)
);

#Loading Cities:
SET GLOBAL local_infile = true; # must be executed at the start of running eah file
LOAD DATA LOCAL INFILE 'C:/Users/vaylo/OneDrive/Desktop/DBM/Project/Data_transformed/cities_csv.csv'
INTO TABLE cities
FIELDS terminated BY ';;;' ESCAPED BY '\t'
IGNORE 0 LINES;



Select * from cities
where city = "New York";

